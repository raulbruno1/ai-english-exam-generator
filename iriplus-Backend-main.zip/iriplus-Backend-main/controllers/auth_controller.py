"""
Authentication controller.

Provides authentication features using JWT stored in HttpOnly cookies:
- Login
- Return authenticated user profile (/me)
- Refresh JWT cookie
- Logout
- Verify user email address using signed verification tokens

Email verification tokens are generated and validated via itsdangerous.
"""

import os
import random
from flask import jsonify, request, current_app
from flask_jwt_extended import (
    create_access_token,
    get_jwt_identity,
    jwt_required,
    set_access_cookies,
    unset_jwt_cookies,
)
import bcrypt
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from orm_models import User, db
from extensions.mail_extension import mail
from utils.brevo_mail import send_brevo_email
from utils.email_utils import _build_email_layout
from utils.types_enum import UserType
from services.captcha_service import verify_captcha
from controllers.user_controller import serialize_user
from urllib.parse import urlencode
from flask import redirect


# ----------------------------------------------------------
# HELPERS
# ----------------------------------------------------------
def normalize_email(email: str) -> str:
    """
    Normalize an email address by stripping whitespace and converting to lowercase.
    Args:
        email: The email address to normalize.
    Returns:
        The normalized email address.
    """
    return email.strip().lower()

def generate_code() -> str:
    """
    Generate a random 6-digit code.
    Returns:
        A string representing a zero-padded 6-digit code.
    """
    return f"{random.randint(0, 999999):06d}"

def get_reset_ttl_seconds() -> int:
    """
    Get the password reset TTL in seconds from the environment variable.
    Returns:
        The TTL in seconds, defaulting to 900 (15 minutes).
    """
    raw = os.getenv("PASSWORD_RESET_TTL_SECONDS", "900")
    try:
        return int(raw)
    except ValueError:
        return 900

def reset_code_key(email: str) -> str:
    """
    Generate the Redis key for storing a password reset code.
    Args:
        email: The user's email address.
    Returns:
        A string representing the Redis key for the reset code.
    """
    return f"pwdreset:code:{normalize_email(email)}"

def confirm_verification_token(token: str, expiration=3600):
    """
    Validate a signed email verification token.

    Args:
        token: Token received from the verification URL.
        expiration: Maximum allowed age of the token in seconds.

    Returns:
        The decoded email address if the token is valid.
        None if the token is invalid or expired.
    """
    serializer = URLSafeTimedSerializer(current_app.config["SECRET_KEY"])
    try:
        email = serializer.loads(token, salt="email-verification", max_age=expiration)
        return email
    except (SignatureExpired, BadSignature):
        return None


# ----------------------------------------------------------
# LOGIN
# ----------------------------------------------------------

def login_controller():
    """
    Authenticate user credentials and issue a JWT cookie.

    Expected JSON body:
        {
            "email": "<string>",
            "password": "<string>"
        }

    On success:
        Stores JWT access token in an HttpOnly cookie
        and returns {"msg": "login ok"}

    Returns:
        200 OK on valid login.
        400 if required fields are missing.
        401 if credentials are invalid.
        403 if the user's email is not yet verified.
    """
    data = request.get_json(silent=True) or {}

    captcha_token = data.get("captcha")

    if not verify_captcha(captcha_token): # type: ignore
        return jsonify({"msg": "Captcha verification failed"}), 400

    email = data.get("email")
    password = data.get("password")

    if not isinstance(email, str) or not isinstance(password, str):
        return jsonify({"msg": "Invalid credentials"}), 401
    normalized = normalize_email(email)

    user = User.query.filter_by(email=normalized).first()

    # Dummy hash to mitigate timing attacks
    dummy_hash = bcrypt.hashpw(b"dummy_password", bcrypt.gensalt())

    if not user or not isinstance(user.passwd, str):
        bcrypt.checkpw(password.encode("utf-8"), dummy_hash)
        return jsonify({"msg": "Invalid credentials"}), 401

    # Soft delete validation
    if user.date_deleted is not None:
        return jsonify({"msg": "Invalid credentials"}), 401
    # Email verification validation
    if not user.is_verified:
        return jsonify({"msg": "Email not verified"}), 403

    if not bcrypt.checkpw(password.encode("utf-8"), user.passwd.encode("utf-8")):
        return jsonify({"msg": "Invalid credentials"}), 401

    token = create_access_token(identity=str(user.id))
    response = jsonify({"msg": "login ok"})
    set_access_cookies(response, token)

    return response, 200


# ----------------------------------------------------------
# GET PROFILE
# ----------------------------------------------------------

@jwt_required()
def me_controller():
    """
    Return the profile of the authenticated user.

    Requires:
        A valid JWT access token in an HttpOnly cookie.

    Returns:
        200 OK with user fields.
        404 if the authenticated user cannot be found.
        403 if the authenticated user is not verified
    """
    user_id = get_jwt_identity()
    user = db.session.get(User, user_id)
    if not user or user.date_deleted is not None:
        return jsonify({"msg": "User not found"}), 404
    if user.is_verified is False:
        return jsonify({"msg": "Email not verified"}), 403

    return jsonify(serialize_user(user)), 200


# ----------------------------------------------------------
# REFRESH
# ----------------------------------------------------------

@jwt_required()
def refresh_controller():
    """
    Refresh the user's JWT and reissue an HttpOnly cookie.

    Returns:
        200 OK with {"msg": "token refreshed"}.
    """
    user_id = get_jwt_identity()
    new_token = create_access_token(identity=str(user_id))
    response = jsonify({"msg": "token refreshed"})
    set_access_cookies(response, new_token)

    return response, 200


# ----------------------------------------------------------
# LOGOUT
# ----------------------------------------------------------

def logout_controller():
    """
    Clear the JWT cookie and log the user out.

    Returns:
        200 OK with {"msg": "logout ok"}.
    """
    response = jsonify({"msg": "logout ok"})
    unset_jwt_cookies(response)
    return response, 200


# ----------------------------------------------------------
# VERIFICAR EMAIL
# ----------------------------------------------------------
def _frontend_redirect(path: str, **params):
    base = os.getenv("FRONTEND_REDIRECT_URL", "http://localhost:4200").rstrip("/")
    query = urlencode(params)
    return redirect(f"{base}{path}?{query}" if query else f"{base}{path}")

def verify_email_controller(token: str):
    email = confirm_verification_token(token)

    if not email:
        return _frontend_redirect("/login", verified="invalid")

    user = User.query.filter_by(email=email).first()

    if not user or user.date_deleted is not None:
        return _frontend_redirect("/login", verified="not-found")

    if user.is_verified:
        return _frontend_redirect("/login", verified="already")

    user.is_verified = True
    db.session.commit()

    return _frontend_redirect("/login", verified="success")
# ----------------------------------------------------------
# SEND CODE FOR PASSWORD RESET
# ----------------------------------------------------------

def send_reset_code_controller():
    """
    Send a password reset code to the user's email.
    Expected JSON body:
        {
            "email": "<string>"
        }
    Returns:
        200 OK if the code was sent.
        400 if the email field is missing.
        404 if no user matches the provided email address.
    """
    data = request.get_json(silent=True) or {}

    captcha_token = data.get("captcha")

    if not verify_captcha(captcha_token): # type: ignore
        return jsonify({"msg": "Captcha verification failed"}), 400
    email = data.get("email")

    if not isinstance(email, str) or not email.strip():
        return jsonify({"msg": "email required"}), 400

    normalized = normalize_email(email)

    user = User.query.filter_by(email=normalized).first()
    if user and user.date_deleted is None and user.is_verified:
        code = generate_code()
        ttl_seconds = get_reset_ttl_seconds()

        redis_client = current_app.extensions["redis_client"]
        key = reset_code_key(normalized)
        redis_client.setex(key, ttl_seconds, code)

        minutes = ttl_seconds // 60

        content_html = f"""
        <p style="margin:0 0 14px 0;color:#111111;font-size:16px;line-height:1.6;">
            Use the following code to reset your password:
        </p>

        <div style="
            margin:20px 0;
            font-size:28px;
            font-weight:700;
            letter-spacing:4px;
            color:#1a3a21;
        ">
            {code}
        </div>

        <p style="margin:0 0 24px 0;color:#6c757d;font-size:15px;line-height:1.6;">
            This code expires in {minutes} minutes.
        </p>
        """

        html = _build_email_layout(
            title="Password Recovery",
            greeting="Hello,",
            content_html=content_html,
            footer="If you did not request a password reset, you can ignore this email.",
        )

        send_brevo_email(
            to_email=normalized,
            subject="Your password recovery code",
            html_content=html,
        )

    # Always send code 200 even if the user doesn't exist avoiding user enumeration
    return jsonify({"msg": "code sent"}), 200

def verify_reset_code_controller():
    """
    Verify a password reset code sent to the user's email.
    Expected JSON body:
        {
            "email": "<string>",
            "code": "<string>"
        }
    Returns:
        200 OK if the code is valid.
        400 if required fields are missing or the code is invalid/expired.
        404 if no user matches the provided email address.
    """
    data = request.get_json(silent=True) or {}
    email = data.get("email")
    code = data.get("code")

    if not isinstance(email, str) or not isinstance(code, str):
        return jsonify({"msg": "email and code required"}), 400

    normalized = normalize_email(email)
    code = code.strip()

    if len(code) != 6 or not code.isdigit():
        return jsonify({"msg": "Invalid or expired code"}), 400

    redis_client = current_app.extensions["redis_client"]
    key = reset_code_key(normalized)

    stored_code = redis_client.get(key)
    if not stored_code:
        return jsonify({"msg": "Invalid or expired code"}), 400

    if stored_code != code:
        return jsonify({"msg": "Invalid or expired code"}), 400

    # Delete key on success and save a flag for that email with a timeout
    redis_client.setex(f"pwdreset:verified:{normalized}", 600, "1")
    redis_client.delete(key)

    return jsonify({"msg": "code valid"}), 200

# ----------------------------------------------------------
# RESET PASSWORD
# ----------------------------------------------------------

def reset_password_controller():
    """
    Reset the user's password after a valid reset code verification.
    Expected JSON body:
        {
            "email": "<string>",
            "newPassword": "<string>"
        }
    Returns:
        200 OK if password was updated.
        400 if fields are missing or invalid.
        404 if user not found.
    """
    data = request.get_json(silent=True) or {}
    email = data.get("email")
    new_password = data.get("newPassword")

    if not isinstance(email, str) or not isinstance(new_password, str):
        return jsonify({"msg": "invalid request"}), 400
    if len(new_password) < 8:
        return jsonify({"msg": "password too short"}), 400

    normalized = normalize_email(email)
    redis_client = current_app.extensions["redis_client"]
    verification_key = f"pwdreset:verified:{normalized}"
    if not redis_client.get(verification_key):
        return jsonify({"msg": "Verification required"}), 403
    user = User.query.filter_by(email=normalized).first()
    if not user or user.date_deleted is not None or user.is_verified is False:
        redis_client.delete(verification_key)
        return jsonify({"msg": "Invalid request"}), 404

    hashed = bcrypt.hashpw(
        new_password.encode("utf-8"),
        bcrypt.gensalt()
    ).decode("utf-8")

    user.passwd = hashed
    db.session.commit()

    redis_client.delete(verification_key)

    return jsonify({"msg": "password updated"}), 200

def change_password_controller():
    """
    Change the password of the authenticated user.

    Expected JSON body:
        {
            "currentPassword": "<string>",
            "newPassword": "<string>"
        }

    Requires:
        A valid JWT access token in an HttpOnly cookie.

    Returns:
        200 OK if password was updated successfully.
        400 if request is invalid or new password is too short.
        401 if current password is incorrect.
        404 if user is not found.
    """
    user_id = get_jwt_identity()
    data = request.get_json(silent=True) or {}

    current_password = data.get("currentPassword")
    new_password = data.get("newPassword")

    if not isinstance(current_password, str) or not isinstance(new_password, str):
        return jsonify({"msg": "Invalid request"}), 400

    current_password = current_password.strip()
    new_password = new_password.strip()

    if not current_password or not new_password:
        return jsonify({"msg": "All password fields are required"}), 400

    if len(new_password) < 8:
        return jsonify({"msg": "Password must be at least 8 characters long"}), 400

    user = db.session.get(User, user_id)

    if not user or user.date_deleted is not None:
        return jsonify({"msg": "User not found"}), 404

    if user.is_verified is False:
        return jsonify({"msg": "Email not verified"}), 403

    if not isinstance(user.passwd, str):
        return jsonify({"msg": "Invalid user password"}), 400

    if not bcrypt.checkpw(
        current_password.encode("utf-8"),
        user.passwd.encode("utf-8")
    ):
        return jsonify({"msg": "Current password is incorrect"}), 401

    if bcrypt.checkpw(
        new_password.encode("utf-8"),
        user.passwd.encode("utf-8")
    ):
        return jsonify({"msg": "New password must be different from the current password"}), 400

    hashed = bcrypt.hashpw(
        new_password.encode("utf-8"),
        bcrypt.gensalt()
    ).decode("utf-8")

    user.passwd = hashed
    db.session.commit()

    return jsonify({"msg": "Password updated successfully"}), 200
