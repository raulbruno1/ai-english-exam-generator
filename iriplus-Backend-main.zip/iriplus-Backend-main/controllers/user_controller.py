"""Controller logic for user management.

This module defines the CRUD operations for User entities.
It provides endpoints for creating, retrieving, updating, and deleting users,
including type-specific filtering for Students, Teachers, and Coordinators.
"""
from __future__ import annotations
from datetime import datetime
from typing import List, Set
import bcrypt
from flask import request, jsonify
from flask_jwt_extended import get_jwt_identity
from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy.orm import joinedload
from orm_models import db, User, Class
from utils.types_enum import UserType
from utils.email_utils import send_welcome_email, send_email_change_verification_email
from utils.token_utils import generate_verification_token
from services.captcha_service import verify_captcha


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------

def serialize_user(user: User) -> dict:
    """Serialize a User ORM instance into a JSON-compatible dictionary.

    Args:
        user: SQLAlchemy User model instance.

    Returns:
        A dictionary containing serializable user attributes.
    """
    payload = {
        "id": user.id,
        "name": user.name,
        "surname": user.surname,
        "email": user.email,
        "dni": user.dni,
        "profile_picture": user.profile_picture,
        "type": user.type.value if user.type else None,
        "accumulated_xp": user.accumulated_xp,
        "student_level_id": user.student_level_id,
        "student_class_id": user.student_class_id,
        "is_verified": user.is_verified,
        "date_created": user.date_created.isoformat() if user.date_created else None,
    }

    if user.type == UserType.STUDENT:
        clazz = user.student_class
        level = user.student_level

        payload["class_code"] = clazz.class_code if clazz else None

        payload["student_class"] = (
            {
                "id": clazz.id,
                "class_code": clazz.class_code,
                "description": clazz.description,
            }
            if clazz and clazz.date_deleted is None
            else None
        )

        payload["student_level"] = (
            {
                "id": level.id,
                "description": level.description,
                "min_xp": level.min_xp,
            }
            if level and level.date_deleted is None
            else None
        )

    if user.type == UserType.TEACHER:
        classes = [c for c in (user.teacher_classes or []) if c.date_deleted is None] # type: ignore[operator]
        payload["teacher_classes"] = [
            {
                "id": c.id,
                "class_code": c.class_code,
                "description": c.description,
                "suggested_level": c.suggested_level,
                "max_capacity": c.max_capacity,
                "students_count": sum(
                    1 for student in (c.students or []) if student.date_deleted is None and student.is_verified is True
                ),
            }
            for c in classes
        ]
    return payload

# ---------------------------------------------------------------------------
# Controller functions
# ---------------------------------------------------------------------------

def create_user(user_type: UserType):
    """Create a new user of a given type (Student, Teacher, Coordinator).

    Args:
        user_type: String representation of the user type to assign.

    Returns:
        JSON response containing the new user data or an error message.
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"message": "Invalid JSON body."}), 400
    # Validate required fields.
    required_fields = ["name", "surname", "email", "passwd", "dni"]
    if user_type == UserType.STUDENT:
        required_fields.append("student_class_id")
    missing_fields = [field for field in required_fields if field not in data]
    if missing_fields:
        return jsonify({"message": f"Missing required fields: {', '.join(missing_fields)}"}), 400
    try:
        # Hash the provided password using bcrypt with salt.
        hashed_password = bcrypt.hashpw(
            data["passwd"].encode("utf-8"), bcrypt.gensalt()
        ).decode("utf-8")

        # Create new user instance.
        new_user = User(
            name=data["name"],
            surname=data["surname"],
            email=data["email"].lower(),
            passwd=hashed_password,
            dni=data["dni"],
            type=user_type,
            accumulated_xp=data.get("accumulated_xp", 0),
            profile_picture=data.get("profile_picture"),
            student_level_id=data.get("student_level_id"),
            student_class_id=data.get("student_class_id"),
            date_created=datetime.now(),
            is_verified=False
        )

        # Commit transaction.
        db.session.add(new_user)
        db.session.commit()
        token = generate_verification_token(new_user.email)
        send_welcome_email(new_user.email, new_user.name, token)

        return jsonify({
            "message": "User created successfully. Verification email sent.",
            "user": serialize_user(new_user)
        }), 201

    except KeyError:
        # Handle invalid user type string.
        return jsonify({"message": f"Invalid user type: {user_type}"}), 400
    except SQLAlchemyError as err:
        db.session.rollback()
        return jsonify({"message": f"Database error: {err}"}), 500
    except Exception as err:  # pylint: disable=broad-except
        db.session.rollback()
        return jsonify({"message": f"Unexpected error: {err}"}), 500

def register_student():
    """Create a new Student user.

    Validates:
    - Required fields
    - Email uniqueness
    - DNI uniqueness
    - Class existence
    - Class capacity
    - Soft delete constraints

    Returns:
        201 Created on success
        400 Bad request for invalid input
        404 Class not found
        409 Email or DNI already exists
        422 Class is full
    """

    data = request.get_json(silent=True) or {}

    captcha_token = data.get("captcha")

    if not verify_captcha(captcha_token): # type: ignore
        return jsonify({"message": "Captcha verification failed"}), 400
    user_data = data.get("user", {})

    required_fields = ["name", "surname", "email", "passwd", "dni", "class_code"]

    missing = [f for f in required_fields if not user_data.get(f)]
    if missing:
        return jsonify({
            "message": f"Missing required fields: {', '.join(missing)}"}), 400
    name = user_data["name"].strip()
    surname = user_data["surname"].strip()
    email = user_data["email"].strip().lower()
    passwd = user_data["passwd"]
    dni = user_data["dni"].strip()
    class_code = user_data["class_code"].strip()

    try:
        # Check for existing email or DNI
        existing_email = User.query.filter(func.lower(User.email) == email).first()
        if existing_email and not existing_email.date_deleted:
            return jsonify({"message": "Email already exists."}), 409
        existing_dni = User.query.filter(func.trim(User.dni) == dni).first()
        if existing_dni and not existing_dni.date_deleted:
            return jsonify({"message": "DNI already exists."}), 409
        # Verify class existence and capacity
        clazz = Class.query.filter(func.trim(Class.class_code) == class_code).first()
        if not clazz or clazz.date_deleted is not None:
            return jsonify({"message": "Class not found."}), 404
        current_students = (
            db.session.query(func.count(User.id)) # pylint: disable=not-callable
            .filter(
                User.student_class_id == clazz.id,
                User.date_deleted.is_(None),
                User.is_verified.is_(True),
            ).scalar()
        )

        if current_students >= clazz.max_capacity:
            return jsonify({"message": "Class is full."}), 422
        # Hash password
        hashed_password = bcrypt.hashpw(
            passwd.encode("utf-8"), bcrypt.gensalt()
        ).decode("utf-8")

        # Create new student user
        new_user = User(
            name=name,
            surname=surname,
            email=email,
            passwd=hashed_password,
            dni=dni,
            type=UserType.STUDENT,
            accumulated_xp=0,
            student_level_id=None,
            student_class_id=clazz.id,
            date_created=datetime.now(),
            is_verified=False
        )

        db.session.add(new_user)
        db.session.commit()

        # Send verification email
        token = generate_verification_token(new_user.email)
        send_welcome_email(new_user.email, new_user.name, token)

        return jsonify({
            "message": "Student created successfully. Verification email sent."
        }), 201
    except SQLAlchemyError as err:
        db.session.rollback()
        return jsonify({"message": f"Database error: {err}"}), 500
    except Exception as err:  # pylint: disable=broad-except
        db.session.rollback()
        return jsonify({"message": f"Unexpected error: {err}"}), 500

def get_user(user_id: int):
    """Retrieve a single user by ID.

    Args:
        user_id: Primary key of the user to fetch.

    Returns:
        JSON response containing user data or a 404 message.
    """
    user = User.query.get(user_id)
    if not user or user.date_deleted is not None:
        return jsonify({"message": "User not found."}), 404

    return jsonify(serialize_user(user)), 200

def get_user_by_email(user_email: str):
    """Retrieve a single user by email.

    Args:
        email: Email address of the user to fetch.
    Returns:
        JSON response containing user data or a 404 message.
    """

    normalized_email = user_email.strip().lower()

    user = User.query.filter(User.email == normalized_email).first()
    if not user or user.date_deleted is not None:
        return jsonify({"message": "User not found."}), 404

    return jsonify(serialize_user(user)), 200

def get_user_by_dni(dni: str):
    """Retrieve a single user by DNI.

    Args:
        dni: DNI of the user to fetch.
    Returns:
        JSON response containing user data or a 404 message.
    """
    normalized_dni = dni.strip()

    user = User.query.filter(func.trim(User.dni) == normalized_dni).first()
    if not user or user.date_deleted is not None:
        return jsonify({"message": "User not found."}), 404

    return jsonify(serialize_user(user)), 200


def get_all_users(user_type: str):
    """Retrieve all users of a specific type.

    Args:
        user_type: The user role to filter by (Student, Teacher, Coordinator).

    Returns:
        JSON response with a list of users or an error message.
    """
    try:
        # Convert user_type string to corresponding Enum value.
        user_enum = UserType[user_type.upper()]
    except KeyError:
        return jsonify({"message": f"Invalid user type: {user_type}"}), 400

    users = User.query.filter(User.type== user_enum, User.date_deleted.is_(None)).order_by(User.surname.asc(), User.name.asc()).all()
    if not users:
        return jsonify({"message": f"No {user_type.lower()}s found."}), 404

    return jsonify([serialize_user(user) for user in users]), 200

def get_my_students():
    """Retrieve all Students assigned to the requesting Teacher (Teacher only).

    Returns:
        A JSON list of students (possibly empty).
    """
    teacher_id = int(get_jwt_identity())
    teacher = User.query.get(teacher_id)

    if not teacher or teacher.date_deleted is not None:
        return jsonify({"message": "User not found."}), 404

    if teacher.type != UserType.TEACHER:
        return jsonify({"message": "Forbidden"}), 403

    teacher_classes = getattr(teacher, "teacher_classes", None) or []
    class_ids: Set[int] = {c.id for c in teacher_classes if getattr(c, "date_deleted", None) is None}

    if not class_ids:
        return jsonify([]), 200

    students: List[User] = (
        User.query
        .filter(
            User.type == UserType.STUDENT,
            User.date_deleted.is_(None),
            User.student_class_id.in_(class_ids),
        )
        .options(
            joinedload(User.student_class), # type: ignore[arg-type]
            joinedload(User.student_level) # type: ignore[arg-type]
        )
        .order_by(User.surname.asc(), User.name.asc())
        .all()
    )

    return jsonify([serialize_user(s) for s in students]), 200

def update_user(user_id: int):
    """Update an existing user's mutable fields."""
    user = User.query.get(user_id)
    if not user or user.date_deleted is not None:
        return jsonify({"message": "User not found."}), 404

    data = request.get_json(silent=True)
    if not data:
        return jsonify({"message": "Invalid JSON body."}), 400

    personal_fields = {"name", "surname", "email", "dni"}
    is_personal_update = any(field in data for field in personal_fields)

    if is_personal_update:
        provided_password = (data.get("passwd") or "").strip()
        if not provided_password:
            return jsonify({"message": "Current password is required."}), 400

        if not bcrypt.checkpw(
            provided_password.encode("utf-8"),
            user.passwd.encode("utf-8"),
        ):
            return jsonify({"message": "Current password is incorrect."}), 401

        if "name" in data:
            normalized_name = str(data["name"]).strip()
            if not normalized_name:
                return jsonify({"message": "Name is required."}), 400
            data["name"] = normalized_name

        if "surname" in data:
            normalized_surname = str(data["surname"]).strip()
            if not normalized_surname:
                return jsonify({"message": "Surname is required."}), 400
            data["surname"] = normalized_surname

        if "email" in data:
            normalized_email = str(data["email"]).strip().lower()
            if not normalized_email:
                return jsonify({"message": "Email is required."}), 400

            existing_email = (
                User.query.filter(
                    func.lower(User.email) == normalized_email,
                    User.id != user.id,
                    User.date_deleted.is_(None),
                    User.is_verified.is_(True),
                ).first()
            )
            if existing_email:
                return jsonify({"message": "Email already exists."}), 409

            data["email"] = normalized_email

        if "dni" in data:
            normalized_dni = str(data["dni"]).strip()
            if not normalized_dni:
                return jsonify({"message": "DNI is required."}), 400

            existing_dni = (
                User.query.filter(
                    func.trim(User.dni) == normalized_dni,
                    User.id != user.id,
                    User.date_deleted.is_(None),
                    User.is_verified.is_(True),
                ).first()
            )
            if existing_dni:
                return jsonify({"message": "DNI already exists."}), 409

            data["dni"] = normalized_dni

    if "student_class_id" in data:
        new_class_id = data["student_class_id"]

        if new_class_id is not None:
            clazz = Class.query.get(new_class_id)
            if not clazz or clazz.date_deleted is not None:
                return jsonify({"message": "Class not found."}), 404

            if user.student_class_id != new_class_id:
                current_students = (
                    db.session.query(func.count(User.id))  # pylint: disable=not-callable
                    .filter(
                        User.student_class_id == clazz.id,
                        User.date_deleted.is_(None),
                        User.is_verified.is_(True),
                    )
                    .scalar()
                )

                if current_students >= clazz.max_capacity:
                    return jsonify(
                        {"message": "Class is full. No spots available."}
                    ), 409

    previous_email = user.email
    updatable_fields = [
        "name",
        "surname",
        "email",
        "dni",
        "profile_picture",
        "accumulated_xp",
        "student_level_id",
        "student_class_id",
    ]

    for field in updatable_fields:
        if field in data:
            setattr(user, field, data[field])

    email_changed = "email" in data and data["email"] != previous_email
    if email_changed:
        user.is_verified = False

    try:
        db.session.commit()
    except IntegrityError as err:
        db.session.rollback()
        error_text = str(err.orig).lower()

        if "email" in error_text:
            return jsonify({"message": "Email already exists."}), 409
        if "dni" in error_text:
            return jsonify({"message": "DNI already exists."}), 409

        return jsonify({"message": "A duplicate value already exists."}), 409
    except SQLAlchemyError as err:
        db.session.rollback()
        return jsonify({"message": f"Database error: {err}"}), 400
    except Exception as err:  # pylint: disable=broad-except
        db.session.rollback()
        return jsonify({"message": f"Unexpected error: {err}"}), 500

    if email_changed:
        try:
            token = generate_verification_token(user.email)
            send_email_change_verification_email(user.email, user.name, token)
        except Exception:  # pylint: disable=broad-except
            pass

    return jsonify(serialize_user(user)), 200


def delete_user(user_id: int):
    """
    Soft delete a user by setting date_deleted.
    """
    user = User.query.filter(
        User.id == user_id
    ).first()

    if not user or user.date_deleted is not None:
        return jsonify({"message": "User not found or already deleted."}), 404

    try:
        user.is_verified = 0
        user.date_deleted = datetime.now()
        db.session.commit()

        return jsonify({
            "message": "User deleted successfully (soft delete).",
            "date_deleted": user.date_deleted.isoformat()
        }), 200

    except SQLAlchemyError as err:
        db.session.rollback()
        return jsonify({"message": f"Database error: {err}"}), 400

    except Exception as err:
        db.session.rollback()
        return jsonify({"message": f"Unexpected error: {err}"}), 500
